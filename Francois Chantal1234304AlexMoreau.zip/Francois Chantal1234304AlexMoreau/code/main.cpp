/** @file main.cpp
Fichier contenant le point d'entrer du programe.
@author   Alex Moreau
@author   Francois Chantal
@date     21 fevrier 2014
@version  1.2
*/

#include "ConsoleMenu.h"

void main() {
    ConsoleMenu menu;
    menu.Run();
    }